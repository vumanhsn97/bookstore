var express = require('express');
var fs = require('fs')
var app = express();
mongoose = require('mongoose');
app.listen(3000);
app.set("view engine", "ejs");
app.set("views", "./views");
app.use(express.static(__dirname + '/public'));
var bodyParser = require('body-parser');
var urlencodedParser = bodyParser.urlencoded({ extended: false });
//connect to server
mongoose.connect('mongodb://bookstore:admin@ds237815.mlab.com:37815/btn04-bookstore');
booksSchema = new mongoose.Schema({
  bookname: {
    type: String,
    maxlength: 50
  },
  bookprice: {
    type: Number,
    min: 0
  },
  bookcontent: String,
  booktype: String,
  viewsbook: {
    type: Number,
    min: 0
  },
  author: String,
});

imagesbookSchema = new mongoose.Schema({
  bookname: String,
  imageurl: String
});

books = mongoose.model('books', booksSchema);
imagesbook = mongoose.model('imagesbook', imagesbookSchema);
app.get("/",function(req, res){
  res.render("trangchu");
});

app.get("/page-:id",function(req, res){

  var i = parseInt(req.params.id);
  if(i<=0) res.send("Don't find");
  else {
    i = (i-1)*12;
    var n = i + 12;
    var j = 1;
    var bookname, typebook, bookprice;
    books.find({}, function (err, result) {
      if (err) return handleError(err);
      var s="";
      var kt = parseInt(result.length/12)+1;
      if(kt<parseInt(req.params.id)) res.send("Don't find");
      else {
        while(i<n){
          if(i<result.length){
            bookname = result[i].bookname;
            booktype = result[i].booktype;
            bookprice = result[i].bookprice;
            s += "document.getElementById('ts"+j+"').innerHTML = " + '"Tên sách: '+ bookname + '";';
            s += "document.getElementById('ls"+j+"').innerHTML = " + '"Loại sách: '+ booktype + '";';
            s += "document.getElementById('gs"+j+"').innerHTML = " + '"Giá: '+ bookprice + 'Đ";';
          }
          if(i>= result.length){
            s += "document.getElementById('s"+j+"').style.border ='none';";
            s += "document.getElementById('s"+j+"').style.width ='0px';";
            s += "document.getElementById('s"+j+"').style.height ='0px';";
          }
          j = j + 1;
          i = i+1;
        }
        s += "document.getElementById('page').innerHTML = "+"'"+parseInt(req.params.id)+"';";
        if(parseInt(req.params.id)==1){
          s += "document.getElementById('prev').innerHTML = '';";
          s += "document.getElementById('prevend').innerHTML = '';";
        }
        var x = parseInt(result.length/12) + 1;
        if(parseInt(req.params.id)==x){
          s += "document.getElementById('next').innerHTML = '';";
          s += "document.getElementById('nextend').innerHTML = '';";
        }
        var t = parseInt(req.params.id) + 1;
        s += "document.getElementById('pr').href = page-"+"'"+t+"';";
        t = parseInt(req.params.id) - 1;
        s += "document.getElementById('nx').href = page-"+"'"+t+"';";
        t = parseInt(result.length/12);
        s += "document.getElementById('nxd').href = page-"+"'"+t+"';";
        s += "window.onload = function() {if(!window.location.hash) {window.location = window.location + '#loaded';window.location.reload();}}"
        fs.writeFile('public/js/data.js', s, 'utf8', function(err){
          if(err)
            throw err;
          else
            console.log("Ghi thanh cong");
          });
        res.render("phantrang");
      }
    });
  }
});
